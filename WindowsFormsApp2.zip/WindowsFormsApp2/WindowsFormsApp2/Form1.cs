﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public bool Reszletes;
        public Form1()
        {
            InitializeComponent();
            Connection.Connect();
            rnb.Text = "Részletes Nézet";
            tb.Enabled = false;
            szb.Enabled = false;
            Reszletes = true;
            Connection.Kiir(listBox1);
        }

        private void szb_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> lista = new List<string>();
                lista.Add(listBox1.SelectedItem.ToString());
                List<string> split = new List<string>(lista[0].Split(new string[] { " " }, StringSplitOptions.None));
                Form3 s = new Form3();
                s.GetData(split[0],split[1],split[2]);
                s.ShowDialog();
                Connection.Kiir(listBox1);
                rnb.Text = "Részletes Nézet";
                tb.Enabled = false;
                szb.Enabled = false;
                Reszletes = true;
            }
            catch(Exception)
            {
                MessageBox.Show("Jelölje ki a szerkeszteni kívánt contactot");
            }
        }
        private void rnb_Click(object sender, EventArgs e)
        {
            if (!Reszletes)
            {
                Connection.Kiir(listBox1);
                rnb.Text = "Részletes Nézet";
                tb.Enabled = false;
                szb.Enabled = false;
                Reszletes = true;
            }
            else
            {
                Connection.Reszletes(listBox1);
                rnb.Text = "Minimális Nézet";
                tb.Enabled = true;
                szb.Enabled = true;
                Reszletes = false;
            }
        }

        private void ueb_Click(object sender, EventArgs e)
        {
            Form2 n = new Form2();
            n.ShowDialog();
            Connection.Kiir(listBox1);
            rnb.Text = "Részletes Nézet";
            tb.Enabled = false;
            szb.Enabled = false;
            Reszletes = true;
        }

        private void tb_Click(object sender, EventArgs e)
        {
            Connection.Torol(listBox1);
            listBox1.Items.Clear();
            Connection.Reszletes(listBox1);
            rnb.Text = "Minimális Nézet";
            tb.Enabled = true;
            szb.Enabled = true;
            Reszletes = false;
        }
    }
}
