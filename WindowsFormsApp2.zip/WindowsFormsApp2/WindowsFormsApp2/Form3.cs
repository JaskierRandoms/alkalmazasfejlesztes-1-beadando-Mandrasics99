﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        public string name = " ";
        public string num = " ";
        public string type = " ";
        public void GetData(string name,string num,string type)
        {
            this.name = name;
            this.num = num;
            this.type = type;
        }
        public Form3()
        {
            InitializeComponent();
            textBox1.Text = name;
            textBox2.Text = num;
            comboBox1.Text = type;
            comboBox1.Items.Add("Mobil");
            comboBox1.Items.Add("Vonalas");
        }

        private void mb2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Sb_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != " " && textBox2.Text != " " && comboBox1.Text != " ")
            {
                Connection.Szerkeszt(num,textBox1,textBox2,comboBox1);
                this.Close();
            }
            else
            {
                MessageBox.Show("Egyik sor sem maradhat üresen");
            }
        }
    }
}
