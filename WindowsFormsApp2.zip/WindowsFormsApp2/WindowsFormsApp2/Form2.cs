﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            tcb.Items.Add("Mobil");
            tcb.Items.Add("Vonalas");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(nb1.Text != " " && tb2.Text != " " && tcb.Text != " ")
            {
                Connection.Ujel(nb1, tb2, tcb);
            }
            else
            {
                MessageBox.Show("Egyik sor sem maradhat üresen");
            }
        }

        private void mb1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
