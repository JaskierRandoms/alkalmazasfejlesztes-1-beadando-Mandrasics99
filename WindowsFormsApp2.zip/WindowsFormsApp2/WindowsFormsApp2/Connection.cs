﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    class Connection
    {
        public static MySqlConnection con = new MySqlConnection("SERVER = localhost; UID=root;PWD=;DATABASE=phonebook");
        public static void Connect()
        {
            try
            {
                con.Open();
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.Message.ToString());
            }
        }

        public static void Kiir(ListBox listBox1)
        {
            string s = String.Format("SELECT name FROM contacts");
            MySqlCommand cmd = new MySqlCommand(s, con);
            MySqlDataReader read = cmd.ExecuteReader();
            listBox1.Items.Clear();
            while (read.Read())
            {
                listBox1.Items.Add(read[0]);
            }
            read.Close();
        }
        public static void Reszletes(ListBox listBox1)
        {
            string s = String.Format("SELECT * FROM contacts");
            MySqlCommand cmd = new MySqlCommand(s, con);
            MySqlDataReader read = cmd.ExecuteReader();
            listBox1.Items.Clear();
            while (read.Read())
            {
                listBox1.Items.Add(read[1] + " " + read[2] + " " + read[3]);
            }
            read.Close();
        }
        public static void Ujel(TextBox nb1, TextBox tb2, ComboBox tcb)
        {
            string s = String.Format("INSERT INTO contacts VALUE(NULL,'{0}','{1}','{2}')", nb1.Text, tb2.Text, tcb.Text);
            MySqlCommand cmd = new MySqlCommand(s, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("A hozzáadás befejeződött");
        }
        public static void Torol(ListBox listBox1)
        {

            try
            {
                List<string> lista = new List<string>();
                lista.Add(listBox1.SelectedItem.ToString());
                List<string> split = new List<string>(lista[0].Split(new string[] { " " }, StringSplitOptions.None));
                string num = split[1];
                string s = String.Format("DELETE FROM contacts WHERE number='{0}'", num);
                MySqlCommand cmd = new MySqlCommand(s, con);
                cmd.ExecuteNonQuery();
            }
            catch(Exception)
            {
                MessageBox.Show("Jelölje ki a törölni kívánt contactot!");
            }
        }
        public static void Szerkeszt(string num, TextBox textBox1,TextBox textBox2, ComboBox comboBox1)
        {
                
                string s = String.Format("UPDATE contacts SET name ='{0}',number ='{1}',type='{2}' WHERE number='{3}'", textBox1.Text, textBox2.Text, comboBox1.Text, num);
                MySqlCommand cmd = new MySqlCommand(s, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("A szerkesztés megtörtént");
        }
    }
}
