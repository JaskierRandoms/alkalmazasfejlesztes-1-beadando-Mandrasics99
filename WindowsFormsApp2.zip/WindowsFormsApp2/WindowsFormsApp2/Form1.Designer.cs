﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.szb = new System.Windows.Forms.Button();
            this.tb = new System.Windows.Forms.Button();
            this.rnb = new System.Windows.Forms.Button();
            this.ueb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(776, 372);
            this.listBox1.TabIndex = 0;
            // 
            // szb
            // 
            this.szb.Location = new System.Drawing.Point(13, 391);
            this.szb.Name = "szb";
            this.szb.Size = new System.Drawing.Size(180, 47);
            this.szb.TabIndex = 1;
            this.szb.Text = "Szerkeszt";
            this.szb.UseVisualStyleBackColor = true;
            this.szb.Click += new System.EventHandler(this.szb_Click);
            // 
            // tb
            // 
            this.tb.Location = new System.Drawing.Point(209, 391);
            this.tb.Name = "tb";
            this.tb.Size = new System.Drawing.Size(180, 47);
            this.tb.TabIndex = 2;
            this.tb.Text = "Töröl";
            this.tb.UseVisualStyleBackColor = true;
            this.tb.Click += new System.EventHandler(this.tb_Click);
            // 
            // rnb
            // 
            this.rnb.Location = new System.Drawing.Point(410, 391);
            this.rnb.Name = "rnb";
            this.rnb.Size = new System.Drawing.Size(180, 47);
            this.rnb.TabIndex = 3;
            this.rnb.Text = "Részletes Nézet";
            this.rnb.UseVisualStyleBackColor = true;
            this.rnb.Click += new System.EventHandler(this.rnb_Click);
            // 
            // ueb
            // 
            this.ueb.Location = new System.Drawing.Point(608, 390);
            this.ueb.Name = "ueb";
            this.ueb.Size = new System.Drawing.Size(180, 47);
            this.ueb.TabIndex = 4;
            this.ueb.Text = "Új elérhetőség";
            this.ueb.UseVisualStyleBackColor = true;
            this.ueb.Click += new System.EventHandler(this.ueb_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ueb);
            this.Controls.Add(this.rnb);
            this.Controls.Add(this.tb);
            this.Controls.Add(this.szb);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Telefonkönyv";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button szb;
        private System.Windows.Forms.Button tb;
        private System.Windows.Forms.Button rnb;
        private System.Windows.Forms.Button ueb;
    }
}

